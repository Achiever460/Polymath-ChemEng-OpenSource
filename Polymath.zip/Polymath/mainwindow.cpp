#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "LinearEqSolver.h" // Include the Linear Equation Solver header file
#include "LinearRegression.h"
#include <QFileDialog>
#include <iostream> // Include for std::cout and std::cerr
#include <fstream>  // Include for file stream operations
#include<eigen3/Eigen/Eigen>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    // Set window title
    setWindowTitle("Polymath-OpenSource");

    // Set window size
    resize(650, 700);

    // Connect the button's clicked signal to the slot
    connect(ui->pushButton, &QPushButton::clicked, this, &MainWindow::openFile);
    // Connect the second push button to the solveProblem slot
    connect(ui->pushButton_2, &QPushButton::clicked, this, &MainWindow::solveLinearEq);
    connect(ui->pushButton_3, &QPushButton::clicked, this, &MainWindow::solveLinearRegression);
    connect(ui->pushButton_4, &QPushButton::clicked, this, &MainWindow::solveMoreProblems);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::openFile()
{
    QString newFileName = QFileDialog::getOpenFileName(this, "Open File", QString(), "Text files (*.txt)");
    if (newFileName.isEmpty()) {
        std::cerr << "No file selected." << std::endl;
        return;
    } else {
        selectedFileName = newFileName;
        std::cout << "Selected file: " << selectedFileName.toStdString() << std::endl; // Debug output
    }
}


/*
void MainWindow::solveProblem()
{
    if (selectedFileName.isEmpty()) {
        std::cerr << "No file selected." << std::endl;
        return;
    }

    solver(selectedFileName.toStdString()); // Call solver function from Solver.cpp
}

void MainWindow::solveAndDisplayResult() {
    if (selectedFileName.isEmpty()) {
        std::cerr << "No file selected." << std::endl;
        return;
    }

    // Call your solver function
    QString result = solver(selectedFileName.toStdString());

    // Update the QTextEdit with the result
    ui->resultTextEdit->setText(result);
}
*/
void MainWindow::openFileLinearEqSolver()
{
    if (selectedFileName.isEmpty()) {
        std::cerr << "No file selected." << std::endl;
        return;
    }

    QString result = solverLinearEqSolver(selectedFileName.toStdString());
    ui->resultTextEdit->setText(result);
}

void MainWindow::openFileLinearRegression()
{
    if (selectedFileName.isEmpty()) {
        std::cerr << "No file selected." << std::endl;
        return;
    }

    QString result = solverLinearRegression(selectedFileName.toStdString());
    ui->resultTextEdit->setText(result);
}


void MainWindow::solveLinearEq()
{
    if (selectedFileName.isEmpty()) {
        std::cerr << "No file selected." << std::endl;
        return;
    }

    // Perform linear equation solving
    openFileLinearEqSolver();
}

void MainWindow::solveLinearRegression()
{
    if (selectedFileName.isEmpty()) {
        std::cerr << "No file selected." << std::endl;
        return;
    }

    // Perform linear regression
    openFileLinearRegression();
}

void MainWindow::solveMoreProblems()
{
    // Reset the "Upload" button
    ui->pushButton->setText("Upload");
    ui->pushButton->setStyleSheet("");

    // Reset the "Problem Solved" buttons
    ui->pushButton_2->setText("Solve Linear Equation");
    ui->pushButton_2->setStyleSheet("");
    ui->pushButton_3->setText("Solve Linear Regression");
    ui->pushButton_3->setStyleSheet("");

    // Clear the result text edit
    ui->resultTextEdit->clear();

    // Clear the selected file name
    selectedFileName.clear();
}

void MainWindow::on_pushButton_clicked()
{
    ui->pushButton->setText("Uploaded");
    ui->pushButton->setStyleSheet("background-color: #2196F3; color: white;");

}



void MainWindow::on_pushButton_2_clicked()
{
    ui->pushButton_2->setText("Problem Solved");
    ui->pushButton_2->setStyleSheet("background-color: #2196F3; color: white;");
}



void MainWindow::on_pushButton_3_clicked()
{
    ui->pushButton_3->setText("Problem Solved");
    ui->pushButton_3->setStyleSheet("background-color: #2196F3; color: white;");
}


void MainWindow::on_pushButton_4_clicked()
{
    ui->pushButton_4->setStyleSheet("background-color: #2196F3; color: white;");
}

