#ifndef LINEARREGRESSION_H
#define LINEARREGRESSION_H

#include <eigen3/Eigen/Dense>
#include <QString>

Eigen::VectorXd OLS(const Eigen::MatrixXd& X, const Eigen::VectorXd& y);
Eigen::VectorXd RidgeRegression(const Eigen::MatrixXd& X, const Eigen::VectorXd& y, double alpha);
QString solverLinearRegression(const std::string& fileName);

#endif // LINEARREGRESSION_H
