#include<iostream>
#include<bits/stdc++.h>
#include "LinearEqSolver.h"
#include<fstream>
#include<chrono>
#include<QString>
#include<eigen3/unsupported/Eigen/IterativeSolvers>
#include<eigen3/Eigen/Dense>
#include<eigen3/Eigen/Sparse>
#include<eigen3/Eigen/SparseCholesky>
#include<eigen3/Eigen/IterativeLinearSolvers>
using namespace std;
using namespace Eigen;


double CalculateDeterminant(const MatrixXd& matrix) {
    double determinant = matrix.determinant();
    return determinant;
}


int GetMatrixRank(const MatrixXd& matrix) {
    FullPivLU<MatrixXd> lu_decomp(matrix);
    return lu_decomp.rank();
}


bool isSymmetric(const MatrixXd& matrix) {
    // Check if the matrix is square
    if (matrix.rows() != matrix.cols()) {
        return false;  // A non-square matrix cannot be symmetric
    }

    // Check if the matrix is symmetric
    return matrix.isApprox(matrix.transpose());
}


bool isPositiveDefinite(const MatrixXd &matrix) {
    // Check if the matrix is square
    if (matrix.rows() != matrix.cols()) {
        return false;
    }

    // Attempt Cholesky decomposition
    LLT<MatrixXd> llt(matrix);
    if (llt.info() != Eigen::Success) {
        return false; // Cholesky decomposition failed, not positive definite
    }

    // Check the determinants of principal minors (Sylvester's Criterion)
    for (int i = 1; i <= matrix.rows(); i++) {
        MatrixXd minor = matrix.topLeftCorner(i, i);
        if (minor.determinant() <= 0) {
            return false; // At least one principal minor is not positive definite
        }
    }

    return true; // Matrix is positive definite
}

// Different methods.
// 1. PCG
VectorXd pcgSolver(const MatrixXd& A, const VectorXd& b, const MatrixXd& M, double tol, int maxIter) {
    int n = A.rows();
    VectorXd x = VectorXd::Zero(n);
    VectorXd r = b - A * x;
    VectorXd z = M.triangularView<Lower>().solve(r);  // Preconditioning step
    VectorXd p = z;
    double rho = r.dot(z);
    double rho_prev = rho;

    for (int k = 0; k < maxIter; ++k) {
        VectorXd Ap = A * p;
        double alpha = rho / p.dot(Ap);
        x += alpha * p;
        r -= alpha * Ap;
        z = M.triangularView<Lower>().solve(r);
        rho_prev = rho;
        rho = r.dot(z);
        if (std::sqrt(rho) < tol)
            break;
        double beta = rho / rho_prev;
        p = z + beta * p;
    }

    return x;
}

// 2.MINRES
VectorXd minresSolver(const MatrixXd& A, const VectorXd& b, double tol, int maxIter) {
    int n = A.rows();
    VectorXd x = VectorXd::Zero(n);
    VectorXd r = b - A * x;
    VectorXd p = r;
    double alpha = r.squaredNorm() / (p.transpose() * A * p);
    VectorXd s = r - alpha * A * p;
    VectorXd v = s;
    VectorXd w;
    double beta;
    double rho;
    double rho_prev = r.norm();

    for (int k = 0; k < maxIter; ++k) {
        w = A * v;
        alpha = s.squaredNorm() / (w.transpose() * v);
        x += alpha * v;
        r = s - alpha * w;
        rho = r.norm();
        if (std::sqrt(rho) < tol)
            break;
        beta = rho / rho_prev;
        p = r + beta * (p - w);
        s = r;
        double scaling_factor = s.squaredNorm() / (p.transpose() * A * p);
        v = p + scaling_factor * v;
        rho_prev = rho;
    }

    return x;
}

// 3.SYMM LQ
VectorXd symmlqSolver(const MatrixXd& A, const VectorXd& b, double tol, int maxIter) {
    int n = A.rows();
    VectorXd x = VectorXd::Zero(n);
    VectorXd r = b - A * x;
    VectorXd u = r;
    VectorXd v = u;
    VectorXd w;
    VectorXd p = VectorXd::Zero(n);
    double alpha = r.dot(u);
    double beta;
    double gamma = alpha;

    for (int k = 0; k < maxIter; ++k) {
        w = A * v;
        alpha = r.dot(w);
        w -= (alpha / gamma) * u;
        v -= (alpha / gamma) * p;
        p = w - (w.dot(u) / gamma) * u;
        x += (alpha / gamma) * v;

        r = b - A * x;

        if (r.norm() < tol)
            break;

        beta = r.dot(w);
        gamma = alpha;
        alpha = beta - beta * beta / gamma;
        u = r - (beta / gamma) * u;
    }

    return x;
}

// 4. GMRES
VectorXd gmresSolver(const MatrixXd& A, const VectorXd& b, double tol,int maxIter) {
    GMRES<MatrixXd> solver;
    solver.setMaxIterations(maxIter);
    solver.setTolerance(tol);
    solver.compute(A);

    if (solver.info() != Success) {
        std::cerr << "Decomposition failed" << std::endl;
        return VectorXd();
    }

    VectorXd x = solver.solve(b);

    if (solver.info() != Success) {
        std::cerr << "Solving failed" << std::endl;
        return VectorXd();
    }

    return x;
}

// 5. QMR
VectorXd qmrSolver(const MatrixXd& A, const VectorXd& b, double tol, int maxIter) {
    int n = A.rows();
    VectorXd x = VectorXd::Zero(n);
    VectorXd r = b - A * x;
    VectorXd u = r;
    VectorXd p = u;
    VectorXd q = A * p;
    VectorXd v = q;
    double alpha;
    double beta;
    double rho;
    double omega = 1.0;

    for (int k = 0; k < maxIter; ++k) {
        rho = r.dot(u);
        alpha = rho / v.dot(q);
        x += alpha * p;
        r -= alpha * q;
        u = r;
        rho = r.dot(u);
        if (std::sqrt(rho) < tol)
            break;
        p = u + (rho / rho) * p;
        q = A * p;
        beta = q.dot(r) / rho;
        p = u - beta * p;
        v = q;
        x += omega * p;
        r -= omega * q;
        u = r;
        rho = r.dot(u);
        if (std::sqrt(rho) < tol)
            break;
        alpha = rho / v.dot(q);
        p = u + alpha * p;
        q = A * p;
        beta = q.dot(r) / rho;
        p = u - beta * p;
        v = q;
    }
    return x;
}

// 6.BICG
VectorXd bicgSolver(const MatrixXd& A, const VectorXd& b, double tol, int maxIter) {
    int n = A.rows();
    VectorXd x = VectorXd::Zero(n);
    VectorXd r = b - A * x;
    VectorXd rTilde = r;
    VectorXd p = r;
    VectorXd pTilde = rTilde;
    VectorXd v = A * p;
    VectorXd vTilde = A.transpose() * pTilde;
    double alpha;
    double beta;
    double rho;
    double rhoTilde;
    double omega;

    for (int k = 0; k < maxIter; ++k) {
        rho = r.dot(rTilde);
        if (std::abs(rho) < tol)
            break;

        alpha = rho / v.dot(rTilde);
        x += alpha * p;
        r -= alpha * v;
        rTilde -= alpha * vTilde;

        rhoTilde = r.dot(rTilde);
        beta = rhoTilde / rho;

        p = r + beta * p;
        pTilde = rTilde + beta * pTilde;

        v = A * p;
        vTilde = A.transpose() * pTilde;

        omega = rTilde.dot(v) / v.dot(v);
        x += omega * pTilde;
        r -= omega * v;
        rTilde -= omega * vTilde;
    }

    return x;
}

// Print function
QString printToString(const Eigen::VectorXd& x) {
    QString result;
    for (int i = 0; i < x.size(); ++i) {
        result += "x" + QString::number(i + 1) + " = " + QString::number(x(i)) + "\n";
    }
    return result;
}


// solver function
QString solve(const Eigen::MatrixXd& A, const Eigen::MatrixXd& augmented_A, const Eigen::VectorXd& b) {
    bool symmetric = isSymmetric(A);
    int n = A.rows();
    QString result;

    if (symmetric) {
        result += "The matrix is symmetric.\n";
        bool check = isPositiveDefinite(A);
        if (check) {
            result += "The matrix is Positive Definite.\n";
            // Identity Preconditioner:
            Eigen::MatrixXd M = Eigen::MatrixXd::Identity(n, n);
            double tol = 1e-6;
            int maxIter = 1e4;
            Eigen::VectorXd x = pcgSolver(A, b, M, tol, maxIter);   // PCG Solver
            result += printToString(x);
        } else {
            result += "The matrix is not Positive Definite.\n";
            double tol = 1e-3;
            int maxIter = 1e4;
            Eigen::VectorXd x = minresSolver(A, b, tol, maxIter); // MINRES
            // Eigen::VectorXd x = symmlqSolver(A, b, tol, maxIter); // SYMMLQ
            result += printToString(x);
        }
    } else {
        result += "The matrix is not symmetric.\n";
        double tol = 1e-3;
        int maxIter = 1e4;
        // Eigen::VectorXd x = gmresSolver(A, b, tol, maxIter);    // GMRES
        // Eigen::VectorXd x = qmrSolver(A, b, tol, maxIter);      // QMR
        Eigen::VectorXd x = bicgSolver(A, b, tol, maxIter);     // BICG
        result += printToString(x);
    }

    return result;
}

void printmatrix(const MatrixXd &A){
    int n=A.rows();
    int m=A.cols();
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cout<<A(i,j)<<" ";
        }
        cout<<endl;
    }
    cout<<endl;
}

QString solverLinearEqSolver(const std::string& fileName) {
    QString result; // Use QString to store the result
    // Get the current time before the operation
    auto start = std::chrono::high_resolution_clock::now();

    // Open the file for reading
    std::ifstream inFile(fileName);

    if (!inFile) {
        result = "Error opening the file.\n";
        return result;
    }

    result += "Reading data from the file...\n";
    int eqn, var;

    inFile >> eqn;
    inFile >> var;

    Eigen::MatrixXd A(eqn, var);
    Eigen::VectorXd b(eqn);

    // Read the values of the coefficient matrix A from the file
    for (int i = 0; i < eqn; i++) {
        for (int j = 0; j < var; j++) {
            double value;
            inFile >> value;
            A(i, j) = value;
        }
    }

    // Read the values of vector b from the file
    for (int i = 0; i < eqn; i++) {
        double value;
        inFile >> value;
        b(i) = value;
    }

    // Close the file when you're done
    inFile.close();

    Eigen::MatrixXd augmented_A(eqn, var + 1);
    augmented_A << A, b;

    // Calculate the ranks
    int rank_A = A.fullPivLu().rank();
    int rank_augmented_A = augmented_A.fullPivLu().rank();

    result += "Rank of the matrix: " + QString::number(rank_A) + "\n";
    result += "Rank of the Augmented matrix: " + QString::number(rank_augmented_A) + "\n";

    // Consistency check
    if (eqn != var) {
        result += "Inconsistent because the coefficient matrix is a rectangular matrix\n";
    } else {
        if (rank_A == rank_augmented_A) {
            if (rank_A == var) {
                // If you want to solve for x and print the solution, call the solve function here
                result += "Consistent, unique solution exists\n";
                result += solve(A, augmented_A, b); // Append the result of solve function
            } else {
                result += "Inconsistent because the rank of the coefficient matrix is not equal to the number of variables\n";
            }
        } else {
            result += "Inconsistent because the rank of the coefficient matrix is not equal to the rank of the Augmented matrix\n";
        }
    }

    // Get the current time after the operation
    auto end = std::chrono::high_resolution_clock::now();

    // Calculate the duration in milliseconds
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    result += "Time taken: " + QString::number(duration.count()) + " milliseconds\n";

    // Return the result as a QString
    return result;
}

