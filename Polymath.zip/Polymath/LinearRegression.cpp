#include <iostream>
#include <fstream>
#include <chrono>
#include <eigen3/Eigen/Dense>
#include <vector>
#include <sstream>
#include <QString>

using namespace Eigen;

// Function for Ordinary Least Squares (OLS) regression
Eigen::VectorXd OLS(const Eigen::MatrixXd& X, const Eigen::VectorXd& y) {
    // Compute the OLS coefficients using the normal equation method
    return (X.transpose() * X).ldlt().solve(X.transpose() * y);
}


// Function for Ridge Regression
Eigen::VectorXd RidgeRegression(const Eigen::MatrixXd& X, const Eigen::VectorXd& y, double alpha) {
    int n_features = X.cols();
    return (X.transpose() * X + alpha * Eigen::MatrixXd::Identity(n_features, n_features)).ldlt().solve(X.transpose() * y);
}



QString solverLinearRegression(const std::string& fileName) {
    QString result; // Use QString to store the result
    // Get the current time before the operation
    auto start = std::chrono::high_resolution_clock::now();

    // Read data from the text file
    std::ifstream file(fileName);
    if (!file.is_open()) {
        result = "Error: Unable to open file.\n";
        return result;
    }

    // Initialize vector to hold the input data
    std::vector<std::vector<double>> data;
    std::string line;
    while (std::getline(file, line)) {
        // Split the line into tokens
        std::istringstream iss(line);
        double val;
        std::vector<double> row;
        while (iss >> val) {
            row.push_back(val); // Store each token in a row vector
        }
        data.push_back(row); // Store each row vector in the data vector
    }
    file.close();

    // Convert data to Eigen matrices
    int var = data[0].size(); // Number of independent variables + 1 (for bias term)
    int sample_size = data.size(); // Number of samples
    Eigen::MatrixXd X(sample_size, var); // Initialize matrix for independent variables
    Eigen::VectorXd y(sample_size); // Initialize vector for dependent variable

    // Populate the matrices X and y
    for (int i = 0; i < sample_size; ++i) {
        X(i, 0) = 1.0; // Set bias term
        for (int j = 1; j < var; ++j) {
            X(i, j) = data[i][j - 1]; // Set independent variables
        }
        y(i) = data[i][var - 1]; // Set dependent variable
    }

    // Perform linear regression using OLS
    //VectorXd w = OLS(X,y);

    // Perform linear regression using Ridge Regression with regularization parameter alpha = 0.1
    double alpha = 0.001;
    Eigen::VectorXd w = RidgeRegression(X, y, alpha);

    // Compute predicted values
    Eigen::VectorXd y_pred = X * w;

    // Calculate R-squared value
    double SSE = (y - y_pred).squaredNorm();
    double SST = (y.array() - y.mean()).square().sum();
    double R2 = 1 - (SSE / SST);

    // Output the results
    result += "Intercept: " + QString::number(w(0)) + "\n"; // Output intercept
    result += "Coefficients: ";
    for (int i = 1; i < var; ++i) {
        result += QString::number(w(i)) + " "; // Output coefficients
    }
    result += "\n";

    // Print R-squared value
    result += "R-squared value: " + QString::number(R2) + "\n";

    // Print the equation of the regression line
    result += "Regression Equation: ";
    result += "Y = " + QString::number(w(0));
    for (int i = 1; i < var; ++i) {
        result += " + " + QString::number(w(i)) + " * X" + QString::number(i);
    }
    result += "\n";

    // Get the current time after the operation
    auto end = std::chrono::high_resolution_clock::now();

    // Calculate the duration in milliseconds
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    result += "Time taken: " + QString::number(duration.count()) + " milliseconds\n";

    // Return the result as a QString
    return result;
}


