#ifndef BACKEND_H
#define BACKEND_H

#include <QMainWindow>

class backend : public QMainWindow
{
    Q_OBJECT
public:
    explicit backend(QWidget *parent = nullptr);

signals:
};

#endif // BACKEND_H
