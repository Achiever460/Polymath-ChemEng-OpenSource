#include "backend.h"

backend::backend(QWidget *parent)
    : QMainWindow{parent}
{}
