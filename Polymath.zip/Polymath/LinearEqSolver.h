#ifndef LINEAREQSOLVER_H
#define LINEAREQSOLVER_H

#include <eigen3/Eigen/Dense>
#include <QString>

double CalculateDeterminant(const Eigen::MatrixXd& matrix);
int GetMatrixRank(const Eigen::MatrixXd& matrix);
bool isSymmetric(const Eigen::MatrixXd& matrix);
bool isPositiveDefinite(const Eigen::MatrixXd& matrix);
Eigen::VectorXd pcgSolver(const Eigen::MatrixXd& A, const Eigen::VectorXd& b, const Eigen::MatrixXd& M, double tol, int maxIter);
Eigen::VectorXd minresSolver(const Eigen::MatrixXd& A, const Eigen::VectorXd& b, double tol, int maxIter);
Eigen::VectorXd symmlqSolver(const Eigen::MatrixXd& A, const Eigen::VectorXd& b, double tol, int maxIter);
Eigen::VectorXd gmresSolver(const Eigen::MatrixXd& A, const Eigen::VectorXd& b, double tol, int maxIter);
Eigen::VectorXd qmrSolver(const Eigen::MatrixXd& A, const Eigen::VectorXd& b, double tol, int maxIter);
Eigen::VectorXd bicgSolver(const Eigen::MatrixXd& A, const Eigen::VectorXd& b, double tol, int maxIter);
QString printToString(const Eigen::VectorXd& x);
QString solve(const Eigen::MatrixXd& A, const Eigen::MatrixXd& augmented_A, const Eigen::VectorXd& b);
void printmatrix(const Eigen::MatrixXd& A);
QString solverLinearEqSolver(const std::string& fileName);

#endif // LINEAREQSOLVER_H
